// Safinum Lingua v0.6.0 — Pont vocal navigateur (MAIN world) pour safinum.cm
//
// STRATÉGIE : on crée de VRAIS SpeechSynthesisVoice via Proxy d'un objet natif.
// Chrome accepte un Proxy d'un vrai SpeechSynthesisVoice dans utterance.voice.
// Cela permet au sélecteur de voix du sandbox de voir nos 9 langues camerounaises
// ET à speak() de fonctionner sans TypeError.
(() => {
  "use strict";
  if (window.__safinumVoiceBridgeInstalled || !("speechSynthesis" in window)) return;
  window.__safinumVoiceBridgeInstalled = true;

  const TTS_ENDPOINTS = [
    "https://maryellen-parchable-gertude.ngrok-free.dev/api/audio/tts",
    "http://127.0.0.1:3000/api/audio/tts",
  ];

  // Mapping sandbox yt = {fr:"fr-FR",en:"en-US",fub:"ff",hau:"ha"}
  // On couvre les deux formes (code ISO + code BCP-47 du sandbox)
  const LANG_DEFS = [
    { code: "dua", langs: ["dua", "dua-CM"],        name: "Duálá (Safinum)" },
    { code: "ewo", langs: ["ewo", "ewo-CM"],        name: "Ewondo (Safinum)" },
    { code: "bas", langs: ["bas", "bas-CM"],        name: "Ɓasaá (Safinum)" },
    { code: "bbj", langs: ["bbj", "bbj-CM"],        name: "Ghɔmálá' (Safinum)" },
    { code: "byv", langs: ["byv", "byv-CM"],        name: "Mə̀dûmbà (Safinum)" },
    { code: "fub", langs: ["fub", "fub-CM", "ff"],  name: "Fulfulde (Safinum)" },
    { code: "hau", langs: ["hau", "hau-CM", "ha"],  name: "Haoussa (Safinum)" },
    { code: "bum", langs: ["bum", "bum-CM"],        name: "Bulu (Safinum)" },
    { code: "wes", langs: ["wes", "wes-CM"],        name: "Pidgin (Safinum)" },
  ];

  // Résolution rapide : tag BCP47 -> code interne
  const TAG_TO_CODE = {};
  for (const d of LANG_DEFS)
    for (const l of d.langs) TAG_TO_CODE[l.toLowerCase()] = d.code;

  function resolveLang(tag) {
    if (!tag) return null;
    const lc = String(tag).toLowerCase().replace("_", "-");
    return TAG_TO_CODE[lc] || TAG_TO_CODE[lc.split("-")[0]] || null;
  }

  // ─── Fabriquer de VRAIS SpeechSynthesisVoice par Proxy ───────────────────────
  // On attend d'avoir au moins une voix native réelle, puis on en crée
  // 9 proxies (un par langue camerounaise) qui se comportent comme de vraies voix.
  let safinumVoices = [];   // sera rempli dès qu'on a une voix native
  let voicesBuilt = false;

  function buildVoices(nativeList) {
    if (voicesBuilt || !nativeList.length) return;
    // Prendre n'importe quelle voix native comme modèle de Proxy
    const model = nativeList[0];
    safinumVoices = LANG_DEFS.flatMap((def) =>
      def.langs.map((langTag) =>
        new Proxy(model, {
          get(target, prop) {
            if (prop === "lang")        return langTag;
            if (prop === "name")        return def.name;
            if (prop === "voiceURI")    return "safinum-" + def.code;
            if (prop === "localService")return true;
            if (prop === "default")     return false;
            if (prop === "_safinumCode")return def.code;
            if (prop === Symbol.toPrimitive || prop === "toString") return () => def.name;
            return target[prop];
          },
        })
      )
    );
    voicesBuilt = true;
  }

  // ─── Surcharger getVoices() ──────────────────────────────────────────────────
  const synth = window.speechSynthesis;
  const origGetVoices = synth.getVoices.bind(synth);
  const origSpeak     = synth.speak.bind(synth);
  const origCancel    = synth.cancel.bind(synth);

  synth.getVoices = function getVoicesWithSafinum() {
    const native = origGetVoices() || [];
    buildVoices(native);
    // Retourner : voix natives + nos voix Proxy (vrais objets SpeechSynthesisVoice)
    return [...native, ...safinumVoices];
  };

  // ─── speak() : détecter les utterances camerounaises ────────────────────────
  let activeAudio = null;
  let playSeq = 0;
  let pendingBatch = [];
  let batchTimer = null;

  function stopBridgeAudio() {
    playSeq++;
    if (batchTimer) { clearTimeout(batchTimer); batchTimer = null; }
    pendingBatch = [];
    if (activeAudio) {
      try { activeAudio.pause(); activeAudio.currentTime = 0; } catch {}
      activeAudio = null;
    }
  }

  async function playSafinumTTS(text, langCode, rate, lastUtterance) {
    const seq = ++playSeq;
    const clean = (text || "").replace(/\s+/g, " ").trim();
    if (!clean) { lastUtterance?.onend?.(new Event("end")); return; }

    for (const url of TTS_ENDPOINTS) {
      if (seq !== playSeq) return;
      try {
        const resp = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text: clean, language: langCode }),
        });
        if (!resp.ok || !(resp.headers.get("content-type") || "").includes("audio")) continue;
        const blob = await resp.blob();
        if (seq !== playSeq) return;
        const objUrl = URL.createObjectURL(blob);
        const audio = new Audio(objUrl);
        audio.playbackRate = Number(rate) || 0.95;
        activeAudio = audio;
        const done = () => {
          URL.revokeObjectURL(objUrl);
          if (activeAudio === audio) activeAudio = null;
          lastUtterance?.onend?.(new Event("end"));
        };
        audio.onended = done;
        audio.onerror = done;
        await audio.play();
        return;
      } catch { /* Essayer l'endpoint suivant */ }
    }
    lastUtterance?.onerror?.(new Event("error"));
  }

  synth.speak = function speakWithSafinum(utterance) {
    // Chercher le code langue par 3 chemins
    const voiceCode = utterance?.voice?._safinumCode;
    const langCode  = voiceCode
      || resolveLang(utterance?.voice?.lang)
      || resolveLang(utterance?.lang);

    if (!langCode) return origSpeak(utterance);

    // Neutraliser la voix pour qu'origSpeak ne plante pas si on le laisse passer
    // On NE appelle PAS origSpeak — on gère nous-mêmes
    pendingBatch.push({
      text: utterance.text || "",
      langCode,
      rate: utterance.rate || 0.95,
      utterance,
    });
    if (!batchTimer) {
      batchTimer = setTimeout(() => {
        const batch = pendingBatch.slice();
        pendingBatch = [];
        batchTimer = null;
        if (!batch.length) return;
        const fullText = batch.map((b) => b.text).filter(Boolean).join(". ");
        const last = batch[batch.length - 1];
        playSafinumTTS(fullText, last.langCode, last.rate, last.utterance);
      }, 25);
    }
  };

  synth.cancel = function cancelWithSafinum() {
    stopBridgeAudio();
    origCancel();
  };

  // ─── voiceschanged : forcer Vue à recalculer sa liste ────────────────────────
  // On attend que les voix natives soient chargées, puis on les enrichit
  // et on refait sauter voiceschanged pour que le composant Vue recalcule.
  function fireVoicesChanged() {
    const native = origGetVoices();
    if (native.length) buildVoices(native);
    try { synth.dispatchEvent(new Event("voiceschanged")); } catch {}
  }

  // Écouter l'événement natif + tirs programmés
  synth.addEventListener("voiceschanged", fireVoicesChanged, { once: false });
  fireVoicesChanged();
  setTimeout(fireVoicesChanged, 100);
  setTimeout(fireVoicesChanged, 400);
  setTimeout(fireVoicesChanged, 1000);
  setTimeout(fireVoicesChanged, 2500);
})();
