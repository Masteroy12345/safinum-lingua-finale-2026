// Safinum Lingua v0.7.0 — Pont vocal (MAIN world) pour safinum.cm
//
// DEUX CORRECTIONS v0.7 :
// 1. Stack overflow corrigé : on N'écoute PAS voiceschanged sur synth pour le re-déclencher
//    (ça crée une boucle infinie). On utilise uniquement des setTimeout programmés.
// 2. TypeError corrigé : Chrome vérifie utterance.voice via slot C++ interne — aucun Proxy
//    ni objet JS ne passe. Solution : intercepter le SETTER .voice pour capturer le lang
//    et BLOQUER l'assignation avant que Chrome plante. Les "voix" dans getVoices() sont
//    de VRAIS SpeechSynthesisVoice natifs renommés (via lang réécrit dans une iframe cachée),
//    ou on retourne les voix natives + marqueur _safinumCode sans fake objects.
//
// STRATÉGIE FINALE :
// - getVoices() : retourne les voix natives réelles + des descripteurs lisibles
//   (affichés dans le sélecteur du sandbox via un objet plain avec toString)
// - setter .voice : capturé via defineProperty → stocke le code langue, bloque l'assignation
// - speak() : lit le code langue capturé → route vers notre API TTS
(() => {
  "use strict";
  if (window.__safinumVoiceBridgeInstalled || !("speechSynthesis" in window)) return;
  window.__safinumVoiceBridgeInstalled = true;

  const TTS_ENDPOINTS = [
    "https://maryellen-parchable-gertude.ngrok-free.dev/api/audio/tts",
    "http://127.0.0.1:3000/api/audio/tts",
  ];

  // Mapping sandbox : yt = {fr:"fr-FR", en:"en-US", fub:"ff", hau:"ha"}
  const LANG_DEFS = [
    { code: "dua", langs: ["dua", "dua-CM"],        name: "Duálá (Safinum)" },
    { code: "ewo", langs: ["ewo", "ewo-CM"],        name: "Ewondo (Safinum)" },
    { code: "bas", langs: ["bas", "bas-CM"],        name: "Ɓasaá (Safinum)" },
    { code: "bbj", langs: ["bbj", "bbj-CM"],        name: "Ghɔmálá' (Safinum)" },
    { code: "byv", langs: ["byv", "byv-CM"],        name: "Mə̀dûmbà (Safinum)" },
    { code: "fub", langs: ["fub", "fub-CM", "ff"],  name: "Fulfulde (Safinum)" },
    { code: "hau", langs: ["hau", "hau-CM", "ha"],  name: "Haoussa (Safinum)" },
    { code: "bum", langs: ["bum", "bum-CM"],        name: "Bulu (Safinum)" },
    { code: "wes", langs: ["wes", "wes-CM"],        name: "Pidgin (Safinum)" },
  ];

  const TAG_TO_CODE = {};
  const TAG_TO_NAME = {};
  for (const d of LANG_DEFS) {
    for (const l of d.langs) {
      TAG_TO_CODE[l.toLowerCase()] = d.code;
      TAG_TO_NAME[l.toLowerCase()] = d.name;
    }
  }

  function resolveLang(tag) {
    if (!tag) return null;
    const lc = String(tag).toLowerCase().replace("_", "-");
    return TAG_TO_CODE[lc] || TAG_TO_CODE[lc.split("-")[0]] || null;
  }

  function resolveName(tag) {
    if (!tag) return null;
    const lc = String(tag).toLowerCase().replace("_", "-");
    return TAG_TO_NAME[lc] || TAG_TO_NAME[lc.split("-")[0]] || null;
  }

  // ─── Intercepter le setter .voice AVANT que Chrome plante ───────────────────
  // Chrome refuse tout objet non-natif SpeechSynthesisVoice.
  // On définit notre propre setter : il capture le lang et bloque l'assignation.
  const UtteranceProto = window.SpeechSynthesisUtterance.prototype;
  const origVoiceDesc = Object.getOwnPropertyDescriptor(UtteranceProto, "voice");

  Object.defineProperty(UtteranceProto, "voice", {
    get() {
      // Retourner notre objet descripteur si on en a un, sinon la voix native
      return this.__safinumVoiceObj ?? (origVoiceDesc?.get ? origVoiceDesc.get.call(this) : null);
    },
    set(v) {
      if (!v) {
        this.__safinumLangCode = null;
        this.__safinumVoiceObj = null;
        try { origVoiceDesc?.set?.call(this, null); } catch {}
        return;
      }
      // Essayer d'extraire le code langue depuis l'objet passé
      let langTag = null;
      try { langTag = v.lang; } catch {}
      const code = resolveLang(langTag);

      if (code) {
        // C'est une de nos voix Safinum (native ou proxy)
        // → capturer le code, NE PAS transmettre à Chrome (ça planterait)
        this.__safinumLangCode = code;
        this.__safinumVoiceObj = v;
        return; // bloquer ici
      }

      // Voix totalement étrangère → tenter l'assignation native
      this.__safinumLangCode = null;
      this.__safinumVoiceObj = null;
      try { origVoiceDesc?.set?.call(this, v); } catch {}
    },
    configurable: true,
    enumerable: true,
  });

  // ─── getVoices() : retourner des descripteurs affichables ───────────────────
  // On ne retourne PAS de faux SpeechSynthesisVoice (TypeError).
  // On retourne les voix natives réelles + des objets descripteurs plain JS
  // avec toString() qui affiche le nom dans le sélecteur.
  // Le sandbox lit .lang et .name pour afficher la liste — ça suffit.
  const synth = window.speechSynthesis;
  const origGetVoices = synth.getVoices.bind(synth);
  const origSpeak = synth.speak.bind(synth);
  const origCancel = synth.cancel.bind(synth);

  // Descripteurs virtuels : plain objects avec les propriétés que le sandbox lit
  function makeSafinumDescriptors() {
    return LANG_DEFS.flatMap((def) =>
      def.langs.map((langTag) => ({
        lang: langTag,
        name: def.name,
        voiceURI: "safinum-" + def.code,
        localService: true,
        default: false,
        _safinumCode: def.code,
        // toString pour l'affichage dans les sélecteurs natifs
        toString() { return def.name; },
      }))
    );
  }

  const safinumDescriptors = makeSafinumDescriptors();

  synth.getVoices = function getVoicesWithSafinum() {
    const native = origGetVoices() || [];
    // Marquer les voix natives qui correspondent à nos langues
    for (const v of native) {
      const code = resolveLang(v.lang);
      if (code && !v._safinumCode) {
        try { v._safinumCode = code; } catch {}
      }
    }
    return [...native, ...safinumDescriptors];
  };

  // ─── speak() ────────────────────────────────────────────────────────────────
  let activeAudio = null;
  let playSeq = 0;
  let pendingBatch = [];
  let batchTimer = null;

  function stopBridgeAudio() {
    playSeq++;
    if (batchTimer) { clearTimeout(batchTimer); batchTimer = null; }
    pendingBatch = [];
    if (activeAudio) {
      try { activeAudio.pause(); activeAudio.currentTime = 0; } catch {}
      activeAudio = null;
    }
  }

  async function playSafinumTTS(text, langCode, rate, lastUtterance) {
    const seq = ++playSeq;
    const clean = (text || "").replace(/\s+/g, " ").trim();
    if (!clean) { lastUtterance?.onend?.(new Event("end")); return; }

    for (const url of TTS_ENDPOINTS) {
      if (seq !== playSeq) return;
      try {
        const resp = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text: clean, language: langCode }),
        });
        if (!resp.ok || !(resp.headers.get("content-type") || "").includes("audio")) continue;
        const blob = await resp.blob();
        if (seq !== playSeq) return;
        const objUrl = URL.createObjectURL(blob);
        const audio = new Audio(objUrl);
        audio.playbackRate = Number(rate) || 0.95;
        activeAudio = audio;
        const done = () => {
          URL.revokeObjectURL(objUrl);
          if (activeAudio === audio) activeAudio = null;
          lastUtterance?.onend?.(new Event("end"));
        };
        audio.onended = done;
        audio.onerror = done;
        await audio.play();
        return;
      } catch { /* Essayer l'endpoint suivant */ }
    }
    lastUtterance?.onerror?.(new Event("error"));
  }

  synth.speak = function speakWithSafinum(utterance) {
    const langCode =
      utterance.__safinumLangCode ||
      resolveLang(utterance?.voice?._safinumCode) ||
      resolveLang(utterance?.voice?.lang) ||
      resolveLang(utterance?.lang);

    if (!langCode) return origSpeak(utterance);

    pendingBatch.push({
      text: utterance.text || "",
      langCode,
      rate: utterance.rate || 0.95,
      utterance,
    });
    if (!batchTimer) {
      batchTimer = setTimeout(() => {
        const batch = pendingBatch.slice();
        pendingBatch = [];
        batchTimer = null;
        if (!batch.length) return;
        const fullText = batch.map((b) => b.text).filter(Boolean).join(". ");
        const last = batch[batch.length - 1];
        playSafinumTTS(fullText, last.langCode, last.rate, last.utterance);
      }, 25);
    }
  };

  synth.cancel = function cancelWithSafinum() {
    stopBridgeAudio();
    origCancel();
  };

  // ─── voiceschanged : tirs programmés UNIQUEMENT (pas d'addEventListener) ────
  // On N'écoute PAS l'événement voiceschanged → ça évite la boucle infinie.
  // On le déclenche seulement depuis des setTimeout pour forcer Vue à recalculer.
  let _firing = false;
  function fireVoicesChangedOnce() {
    if (_firing) return;
    _firing = true;
    try { synth.dispatchEvent(new Event("voiceschanged")); } catch {}
    _firing = false;
  }

  // Attendre que les voix natives soient chargées avant de déclencher
  function waitAndFire(delay) {
    setTimeout(() => {
      fireVoicesChangedOnce();
    }, delay);
  }

  waitAndFire(0);
  waitAndFire(150);
  waitAndFire(500);
  waitAndFire(1200);
  waitAndFire(3000);
})();
