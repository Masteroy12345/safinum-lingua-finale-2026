// Safinum Lingua v0.8.0 — Pont vocal (MAIN world) pour safinum.cm
//
// v0.8 : logs d'erreur détaillés pour diagnostiquer les échecs silencieux,
//         + fallback : si les deux endpoints TTS échouent (CSP, réseau),
//           on lit quand même via le browser TTS natif avec le script phonétique.
(() => {
  "use strict";
  if (window.__safinumVoiceBridgeInstalled || !("speechSynthesis" in window)) return;
  window.__safinumVoiceBridgeInstalled = true;

  const TTS_ENDPOINTS = [
    "https://maryellen-parchable-gertude.ngrok-free.dev/api/audio/tts",
    "http://127.0.0.1:3000/api/audio/tts",
  ];

  // Mapping sandbox : yt = {fr:"fr-FR", en:"en-US", fub:"ff", hau:"ha"}
  const LANG_DEFS = [
    { code: "dua", langs: ["dua", "dua-CM"],        name: "Duálá (Safinum)",       fallbackLang: "fr-FR" },
    { code: "ewo", langs: ["ewo", "ewo-CM"],        name: "Ewondo (Safinum)",       fallbackLang: "fr-FR" },
    { code: "bas", langs: ["bas", "bas-CM"],        name: "Ɓasaá (Safinum)",        fallbackLang: "fr-FR" },
    { code: "bbj", langs: ["bbj", "bbj-CM"],        name: "Ghɔmálá' (Safinum)",     fallbackLang: "fr-FR" },
    { code: "byv", langs: ["byv", "byv-CM"],        name: "Mə̀dûmbà (Safinum)",     fallbackLang: "fr-FR" },
    { code: "fub", langs: ["fub", "fub-CM", "ff"],  name: "Fulfulde (Safinum)",     fallbackLang: "fr-FR" },
    { code: "hau", langs: ["hau", "hau-CM", "ha"],  name: "Haoussa (Safinum)",      fallbackLang: "fr-FR" },
    { code: "bum", langs: ["bum", "bum-CM"],        name: "Bulu (Safinum)",         fallbackLang: "fr-FR" },
    { code: "wes", langs: ["wes", "wes-CM"],        name: "Pidgin (Safinum)",       fallbackLang: "en-US" },
  ];

  const TAG_TO_CODE = {};
  const TAG_TO_DEF = {};
  for (const d of LANG_DEFS) {
    for (const l of d.langs) {
      TAG_TO_CODE[l.toLowerCase()] = d.code;
      TAG_TO_DEF[l.toLowerCase()] = d;
    }
  }

  function resolveLang(tag) {
    if (!tag) return null;
    const lc = String(tag).toLowerCase().replace("_", "-");
    return TAG_TO_CODE[lc] || TAG_TO_CODE[lc.split("-")[0]] || null;
  }

  function resolveDef(code) {
    return LANG_DEFS.find((d) => d.code === code) || null;
  }

  // ─── Intercepter le setter .voice AVANT que Chrome plante ───────────────────
  const UtteranceProto = window.SpeechSynthesisUtterance.prototype;
  const origVoiceDesc = Object.getOwnPropertyDescriptor(UtteranceProto, "voice");

  Object.defineProperty(UtteranceProto, "voice", {
    get() {
      return this.__safinumVoiceObj ?? (origVoiceDesc?.get ? origVoiceDesc.get.call(this) : null);
    },
    set(v) {
      if (!v) {
        this.__safinumLangCode = null;
        this.__safinumVoiceObj = null;
        try { origVoiceDesc?.set?.call(this, null); } catch {}
        return;
      }
      let langTag = null;
      try { langTag = v.lang; } catch {}
      const code = resolveLang(langTag);

      if (code) {
        // Voix Safinum → capturer, NE PAS transmettre (Chrome planterait)
        this.__safinumLangCode = code;
        this.__safinumVoiceObj = v;
        console.info("[Safinum] .voice capturé →", code, "(bloqué avant Chrome)");
        return;
      }
      // Voix native étrangère
      this.__safinumLangCode = null;
      this.__safinumVoiceObj = null;
      try { origVoiceDesc?.set?.call(this, v); } catch {}
    },
    configurable: true,
    enumerable: true,
  });

  // ─── getVoices() ─────────────────────────────────────────────────────────────
  const synth = window.speechSynthesis;
  const origGetVoices = synth.getVoices.bind(synth);
  const origSpeak = synth.speak.bind(synth);
  const origCancel = synth.cancel.bind(synth);

  const safinumDescriptors = LANG_DEFS.flatMap((def) =>
    def.langs.map((langTag) => ({
      lang: langTag,
      name: def.name,
      voiceURI: "safinum-" + def.code,
      localService: true,
      default: false,
      _safinumCode: def.code,
      toString() { return def.name; },
    }))
  );

  synth.getVoices = function getVoicesWithSafinum() {
    const native = origGetVoices() || [];
    return [...native, ...safinumDescriptors];
  };

  // ─── TTS API avec logs et fallback ──────────────────────────────────────────
  let activeAudio = null;
  let playSeq = 0;
  let pendingBatch = [];
  let batchTimer = null;

  function stopBridgeAudio() {
    playSeq++;
    if (batchTimer) { clearTimeout(batchTimer); batchTimer = null; }
    pendingBatch = [];
    if (activeAudio) {
      try { activeAudio.pause(); activeAudio.currentTime = 0; } catch {}
      activeAudio = null;
    }
  }

  async function playSafinumTTS(text, langCode, rate, lastUtterance) {
    const seq = ++playSeq;
    const clean = (text || "").replace(/\s+/g, " ").trim();
    if (!clean) { lastUtterance?.onend?.(new Event("end")); return; }

    console.info("[Safinum] TTS →", { text: clean.slice(0, 60), langCode });

    for (const url of TTS_ENDPOINTS) {
      if (seq !== playSeq) return;
      try {
        const resp = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text: clean, language: langCode }),
        });
        const ct = resp.headers.get("content-type") || "";
        console.info("[Safinum] fetch", url, "→ HTTP", resp.status, ct);
        if (!resp.ok || !ct.includes("audio")) {
          // Si l'API retourne du JSON (fallback phonétique), lire avec le browser TTS
          if (ct.includes("json")) {
            const data = await resp.json().catch(() => null);
            console.info("[Safinum] JSON fallback reçu :", data);
            if (data?.tts_script || data?.web_phonetic) {
              playBrowserFallback(data.tts_script || data.web_phonetic, data.tts_voice_lang || "fr-FR", rate, lastUtterance);
              return;
            }
          }
          continue;
        }
        const blob = await resp.blob();
        if (seq !== playSeq) return;
        const objUrl = URL.createObjectURL(blob);
        const audio = new Audio(objUrl);
        audio.playbackRate = Number(rate) || 0.95;
        activeAudio = audio;
        const done = () => {
          URL.revokeObjectURL(objUrl);
          if (activeAudio === audio) activeAudio = null;
          lastUtterance?.onend?.(new Event("end"));
        };
        audio.onended = done;
        audio.onerror = (e) => { console.warn("[Safinum] audio error", e); done(); };
        await audio.play();
        return;
      } catch (err) {
        console.warn("[Safinum] fetch échoué pour", url, ":", err.message);
      }
    }

    // Fallback navigateur si les deux endpoints échouent (CSP, réseau hors-ligne)
    console.warn("[Safinum] Les deux endpoints TTS ont échoué — fallback browser TTS");
    const def = resolveDef(langCode);
    playBrowserFallback(clean, def?.fallbackLang || "fr-FR", rate, lastUtterance);
  }

  function playBrowserFallback(text, bcp47, rate, lastUtterance) {
    try {
      const u = new SpeechSynthesisUtterance(text);
      u.lang = bcp47;
      u.rate = rate || 0.95;
      u.onend = () => lastUtterance?.onend?.(new Event("end"));
      u.onerror = () => lastUtterance?.onerror?.(new Event("error"));
      origSpeak(u);
    } catch (e) {
      console.warn("[Safinum] browser fallback échoué :", e);
      lastUtterance?.onerror?.(new Event("error"));
    }
  }

  synth.speak = function speakWithSafinum(utterance) {
    const langCode =
      utterance.__safinumLangCode ||
      resolveLang(utterance?.voice?._safinumCode) ||
      resolveLang(utterance?.voice?.lang) ||
      resolveLang(utterance?.lang);

    console.info("[Safinum] speak() →", {
      langCode,
      captured: utterance.__safinumLangCode,
      voiceLang: utterance?.voice?.lang,
      voiceCode: utterance?.voice?._safinumCode,
      uttLang: utterance?.lang,
      text: (utterance?.text || "").slice(0, 50),
    });

    if (!langCode) return origSpeak(utterance);

    pendingBatch.push({
      text: utterance.text || "",
      langCode,
      rate: utterance.rate || 0.95,
      utterance,
    });
    if (!batchTimer) {
      batchTimer = setTimeout(() => {
        const batch = pendingBatch.slice();
        pendingBatch = [];
        batchTimer = null;
        if (!batch.length) return;
        const fullText = batch.map((b) => b.text).filter(Boolean).join(". ");
        const last = batch[batch.length - 1];
        playSafinumTTS(fullText, last.langCode, last.rate, last.utterance);
      }, 25);
    }
  };

  synth.cancel = function cancelWithSafinum() {
    stopBridgeAudio();
    origCancel();
  };

  // ─── voiceschanged : tirs programmés uniquement ──────────────────────────────
  let _firing = false;
  function fireVoicesChangedOnce() {
    if (_firing) return;
    _firing = true;
    try { synth.dispatchEvent(new Event("voiceschanged")); } catch {}
    _firing = false;
  }

  [0, 150, 500, 1200, 3000].forEach((d) => setTimeout(fireVoicesChangedOnce, d));
})();
