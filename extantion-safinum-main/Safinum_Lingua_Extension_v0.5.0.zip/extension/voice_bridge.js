// Safinum Lingua v0.5.0 — Pont vocal navigateur (MAIN world) pour safinum.cm
//
// PROBLÈME RÉSOLU : Chrome refuse `utterance.voice = plainObject` avec
//   "Failed to convert value to 'SpeechSynthesisVoice'"
// car seul un vrai SpeechSynthesisVoice retourné par getVoices() est accepté.
//
// SOLUTION : intercepter le setter `.voice` sur SpeechSynthesisUtterance.prototype
// pour capturer le code langue AVANT que Chrome plante, annuler l'assignation,
// puis détourner speak() vers notre API TTS ElevenLabs/MMS-TTS.
(() => {
  "use strict";
  if (window.__safinumVoiceBridgeInstalled || !("speechSynthesis" in window)) return;
  window.__safinumVoiceBridgeInstalled = true;

  const TTS_ENDPOINTS = [
    "https://maryellen-parchable-gertude.ngrok-free.dev/api/audio/tts",
    "http://127.0.0.1:3000/api/audio/tts",
  ];

  // Mapping lang BCP-47/ISO-639-3 -> code TTS interne
  // yt = {fr:"fr-FR",en:"en-US",fub:"ff",hau:"ha"} (extrait du sandbox Channel.js)
  const LANG_TO_CODE = {
    "dua": "dua", "dua-cm": "dua",
    "ewo": "ewo", "ewo-cm": "ewo",
    "bas": "bas", "bas-cm": "bas",
    "bbj": "bbj", "bbj-cm": "bbj",
    "byv": "byv", "byv-cm": "byv",
    "fub": "fub", "fub-cm": "fub", "ff": "fub",
    "hau": "hau", "hau-cm": "hau", "ha": "hau",
    "bum": "bum", "bum-cm": "bum",
    "wes": "wes", "wes-cm": "wes",
  };

  // Noms des voix virtuelles (pour getVoices — affichage uniquement)
  const VOICE_NAMES = {
    "dua": "Safinum Lingua — Duálá (Voix Homme)",
    "ewo": "Safinum Lingua — Ewondo (Voix Homme)",
    "bas": "Safinum Lingua — Ɓasaá (Voix Homme)",
    "bbj": "Safinum Lingua — Ghɔmálá' (Voix Homme)",
    "byv": "Safinum Lingua — Mə̀dûmbà (Voix Homme)",
    "fub": "Safinum Lingua — Fulfulde (Voix Homme)",
    "ff":  "Safinum Lingua — Fulfulde (Voix Homme)",
    "hau": "Safinum Lingua — Hausa (Voix Homme)",
    "ha":  "Safinum Lingua — Hausa (Voix Homme)",
    "bum": "Safinum Lingua — Bulu (Voix Homme)",
    "wes": "Safinum Lingua — Pidgin Camerounais (Voix Homme)",
  };

  function resolveLang(tag) {
    if (!tag) return null;
    const lc = (tag + "").toLowerCase().replace("_", "-");
    return LANG_TO_CODE[lc] || LANG_TO_CODE[lc.split("-")[0]] || null;
  }

  // ─── Intercepter le setter .voice sur SpeechSynthesisUtterance ───────────────
  // Quand le sandbox fait `utterance.voice = fakeVoiceObj`, Chrome plante.
  // On installe un setter proxy qui : (1) lit le .lang de l'objet passé,
  // (2) stocke le code sur l'utterance, (3) NE transmet PAS à Chrome.
  const UtteranceProto = window.SpeechSynthesisUtterance.prototype;
  const origVoiceDesc = Object.getOwnPropertyDescriptor(UtteranceProto, "voice");

  Object.defineProperty(UtteranceProto, "voice", {
    get() {
      return this.__safinumVoice ?? (origVoiceDesc?.get ? origVoiceDesc.get.call(this) : null);
    },
    set(v) {
      if (v && typeof v === "object" && !v.voiceURI?.startsWith?.("safinum-")) {
        // Vrai SpeechSynthesisVoice natif → passer normalement
        const code = resolveLang(v.lang);
        if (code) {
          // C'est une de nos voix virtuelles renvoyées par getVoices()
          this.__safinumLangCode = code;
          this.__safinumVoice = v;
          // Ne PAS appeler le setter natif avec un objet plain — ignorer
          return;
        }
        try { origVoiceDesc?.set?.call(this, v); } catch {}
        return;
      }
      if (v && v._safinumCode) {
        this.__safinumLangCode = v._safinumCode;
        this.__safinumVoice = v;
        return; // objet virtuel Safinum — NE pas transmettre à Chrome
      }
      // null ou valeur inconnue
      this.__safinumLangCode = null;
      this.__safinumVoice = null;
      try { origVoiceDesc?.set?.call(this, v); } catch {}
    },
    configurable: true,
    enumerable: true,
  });

  // ─── TTS API ─────────────────────────────────────────────────────────────────
  const synth = window.speechSynthesis;
  const origGetVoices = synth.getVoices.bind(synth);
  const origSpeak = synth.speak.bind(synth);
  const origCancel = synth.cancel.bind(synth);

  let activeAudio = null;
  let pendingBatch = [];
  let batchTimer = null;
  let playSeq = 0;

  function stopBridgeAudio() {
    playSeq++;
    if (batchTimer) { clearTimeout(batchTimer); batchTimer = null; }
    pendingBatch = [];
    if (activeAudio) {
      try { activeAudio.pause(); activeAudio.currentTime = 0; } catch {}
      activeAudio = null;
    }
  }

  async function playSafinumTTS(text, langCode, rate, lastUtterance) {
    const seq = ++playSeq;
    const clean = (text || "").replace(/\s+/g, " ").trim();
    if (!clean) {
      lastUtterance?.onend?.(new Event("end"));
      return;
    }
    for (const url of TTS_ENDPOINTS) {
      if (seq !== playSeq) return;
      try {
        const resp = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ text: clean, language: langCode || "fr" }),
        });
        if (!resp.ok || !(resp.headers.get("content-type") || "").includes("audio")) continue;
        const blob = await resp.blob();
        if (seq !== playSeq) return;
        const objUrl = URL.createObjectURL(blob);
        const audio = new Audio(objUrl);
        audio.playbackRate = Number(rate) || 0.95;
        activeAudio = audio;
        const finish = () => {
          URL.revokeObjectURL(objUrl);
          if (activeAudio === audio) activeAudio = null;
          lastUtterance?.onend?.(new Event("end"));
        };
        audio.onended = finish;
        audio.onerror = finish;
        await audio.play();
        return;
      } catch { /* Essayer l'endpoint suivant */ }
    }
    lastUtterance?.onerror?.(new Event("error"));
  }

  // ─── getVoices() : retourner des vrais SpeechSynthesisVoice + nos entrées ────
  // Chrome refuse les plain objects dans utterance.voice.
  // On retourne les voix natives réelles en leur ajoutant un _safinumCode,
  // ET on crée des voix synthétiques via un SpeechSynthesisUtterance détourné.
  // En pratique : pour les langues camerounaises absentes des voix natives,
  // le sandbox ne trouvera rien de natif → notre speak() intercepte par .lang.
  synth.getVoices = function getVoicesWithSafinum() {
    const native = origGetVoices() || [];
    // Ajouter un marqueur sur les voix natives qui correspondent à nos langues
    for (const v of native) {
      const code = resolveLang(v.lang);
      if (code && !v._safinumCode) v._safinumCode = code;
    }
    return native;
    // Note : on ne retourne PAS de faux objets — ça cause le TypeError.
    // On intercepte via le setter .voice et via speak() ci-dessous.
  };

  synth.cancel = function cancelWithSafinum() {
    stopBridgeAudio();
    return origCancel();
  };

  // ─── speak() : détecter les utterances camerounaises par 3 chemins ───────────
  // 1) utterance.__safinumLangCode  (setter .voice capturé ci-dessus)
  // 2) utterance.lang               (le sandbox passe aussi lang= directement)
  // 3) utterance.voice._safinumCode (si le setter a stocké l'objet virtuel)
  synth.speak = function speakWithSafinum(utterance) {
    const langCode =
      utterance.__safinumLangCode ||
      resolveLang(utterance?.voice?._safinumCode) ||
      resolveLang(utterance?.lang);

    if (!langCode) return origSpeak(utterance);

    // Neutraliser la voix pour éviter une 2e erreur dans origSpeak
    utterance.__safinumLangCode = langCode;
    utterance.__safinumVoice = null;
    try { origVoiceDesc?.set?.call(utterance, null); } catch {}

    pendingBatch.push({
      text: utterance.text || "",
      langCode,
      rate: utterance.rate || 0.95,
      utterance,
    });
    if (!batchTimer) {
      batchTimer = setTimeout(() => {
        const batch = pendingBatch.slice();
        pendingBatch = [];
        batchTimer = null;
        if (!batch.length) return;
        const fullText = batch.map((b) => b.text).filter(Boolean).join(". ");
        const last = batch[batch.length - 1];
        playSafinumTTS(fullText, last.langCode, last.rate, last.utterance);
      }, 25);
    }
  };

  // ─── voiceschanged : forcer Vue à recalculer sa liste de voix ────────────────
  function fireVoicesChanged() {
    try { synth.dispatchEvent(new Event("voiceschanged")); } catch {}
  }
  fireVoicesChanged();
  setTimeout(fireVoicesChanged, 50);
  setTimeout(fireVoicesChanged, 300);
  setTimeout(fireVoicesChanged, 800);
  setTimeout(fireVoicesChanged, 2000);
})();
